// EV FaceTime — Token Server
// Run: node server.js  (no npm install needed)
// Open: http://localhost:3000

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

const PORT       = 3000;
const RESOURCE   = 'charlieevert-9284-resource';
const API_KEY    = '1dJV6gYNCEeCwCfETqpVYYeZahOjnidL92ouZRcp4U8CL7uCHEuRJQQJ99BLACHYHv6XJ3w3AAAAACOG4IlM';
const DEPLOYMENT = 'gpt-realtime';

// Keep token-time instructions minimal — full prompt sent via data channel after connect
const INSTRUCTIONS = `You are Sparky, Xcel Energy's AI energy advisor. You're on a phone call with Alex Halper, a residential customer in Denver.

ALEX'S ACCOUNT (Account #PG-4891):
- Current bill: $148.32/month — 847 kWh at $0.621/kWh average
- Late-night draw pattern: ~$42/month between 10pm–6am, consistent with EV charging
- EV Night Plan: $20/month flat for all overnight charging
- Switching saves Alex $22/month, $264/year — bill drops from ~$148 to ~$126

WHAT YOU ALREADY KNOW:
- Alex called in saying his power is completely out
- You checked Xcel's grid: NO outage registered at his address
- Your meter data shows power IS actively flowing to his home right now
- Almost certainly a tripped main breaker — common, easy fix

YOUR FLOW — go through these in order, one at a time:

STEP 1 — OPEN (say this immediately):
"Hey Alex, nice to see you again! I checked your meter and Xcel is actively sending power to your address right now — so this isn't a grid issue. That means we can fix this right now. Can you walk over to your breaker box for me?"

STEP 2 — BREAKER BOX:
Guide him to the gray metal panel — usually garage, basement, or utility closet. Tell him to let you know when he's there. Wait.

STEP 3 — FIND THE TRIPPED BREAKER:
Ask him to look for any breaker that's not fully flipped to ON — tripped ones sit in the middle or slightly toward OFF. Tell him to find the main breaker at the top.

STEP 4 — THE FIX:
Flip the main all the way OFF, then firmly back to ON — he should hear a solid click. Ask if power came back. Celebrate when it does.

STEP 5 — PIVOT TO SAVINGS (only after power is restored):
"While I have you — I was looking at your account. Your bill is $148.32 this month, and about $42 of that is overnight draws between 10pm and 6am. That's exactly what EV charging looks like. Do you have an electric vehicle, or are you thinking about getting one?"

STEP 6 — EV PITCH (if yes, or curious):
"So we have an EV Night Plan — it's $20 a month flat for all overnight charging. Right now you're paying $42 a month for those same draws. That's $22 back in your pocket every month, $264 a year, and your bill goes from $148 down to about $126. Want me to get that added to your account right now?"

STEP 7 — CLOSE:
If yes: "Done — I've added the EV Night Benefit to your plan. It kicks in on your next billing cycle. You'll get a confirmation email shortly."
If not ready: "No problem at all. Your power is back on and that's what matters. Sparky's here anytime — just tap the app."

RULES:
- 1–2 sentences per turn, maximum. Never more.
- Never ask a question you already asked in this conversation.
- Use the real numbers ($148.32, $42/month, $20/month, $264/year) — round numbers feel fake.
- Sound like a knowledgeable friend, not a call center script.
- If Alex goes off-topic, answer briefly and steer back warmly.
- Never say "image", "camera", "frame", or "screenshot".
- Speak naturally — this is a phone call, use contractions, be warm.`;

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  res.setHeader('Access-Control-Allow-Origin', '*');

  // GET /token — fetch ephemeral key from Azure
  if (req.method === 'GET' && url === '/token') {

    // Exact format from Microsoft docs:
    // session.type required, voice goes in audio.output.voice NOT top-level
    const sessionBody = JSON.stringify({
      session: {
        type: 'realtime',
        model: DEPLOYMENT,
        // sage = warm, confident, authoritative — closest to a natural British advisor tone
        // The full instructions + British accent are set via session.update after connection
        audio: {
          output: {
            voice: 'shimmer'
          }
        }
      }
    });

    const options = {
      hostname: `${RESOURCE}.openai.azure.com`,
      path: '/openai/v1/realtime/client_secrets',
      method: 'POST',
      headers: {
        'api-key': API_KEY,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(sessionBody)
      }
    };

    console.log(`\n→ POST https://${options.hostname}${options.path}`);
    console.log('Body:', sessionBody);

    const azReq = https.request(options, (azRes) => {
      let data = '';
      azRes.on('data', c => data += c);
      azRes.on('end', () => {
        console.log(`← Azure status: ${azRes.statusCode}`);
        console.log('← Azure body:', data);

        if (azRes.statusCode !== 200) {
          res.writeHead(azRes.statusCode, {'Content-Type':'application/json'});
          res.end(JSON.stringify({ error: `Azure ${azRes.statusCode}`, detail: data }));
          return;
        }
        try {
          const parsed = JSON.parse(data);
          const token  = parsed.value;
          if (!token) throw new Error('No .value in response: ' + data);
          console.log('✅ Got ephemeral token');
          res.writeHead(200, {'Content-Type':'application/json'});
          res.end(JSON.stringify({ token, resource: RESOURCE }));
        } catch(e) {
          console.error('Parse error:', e.message);
          res.writeHead(500, {'Content-Type':'application/json'});
          res.end(JSON.stringify({ error: e.message }));
        }
      });
    });

    azReq.on('error', e => {
      console.error('Request error:', e.message);
      res.writeHead(500, {'Content-Type':'application/json'});
      res.end(JSON.stringify({ error: e.message }));
    });

    azReq.write(sessionBody);
    azReq.end();
    return;
  }

  // GET / — serve index.html
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    const file = path.join(__dirname, 'index.html');
    if (!fs.existsSync(file)) { res.writeHead(404); res.end('index.html not found'); return; }
    res.writeHead(200, {'Content-Type':'text/html','Cache-Control':'no-cache'});
    fs.createReadStream(file).pipe(res);
    return;
  }

  res.writeHead(404); res.end();
});

server.listen(PORT, () => {
  console.log('─────────────────────────────────────────');
  console.log(`  ✅  Open  http://localhost:${PORT}`);
  console.log(`  📡  ${RESOURCE}.openai.azure.com`);
  console.log(`  🤖  Deployment: ${DEPLOYMENT}`);
  console.log('─────────────────────────────────────────');
});