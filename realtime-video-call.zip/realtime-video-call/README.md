To run:
node server.js

To see:
Go to the port it lists (default is 3000)

Ensure you have node installed