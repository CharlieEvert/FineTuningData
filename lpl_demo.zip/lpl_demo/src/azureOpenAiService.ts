import WebSocket from 'ws';
import { config } from 'dotenv';
import { createOutboundAudioData, createOutboundStopAudioData } from '@azure/communication-call-automation';

config();

let ws: WebSocket; // ACS Media Streaming WebSocket
let realtimeWs: WebSocket; // Azure OpenAI Realtime WebSocket

const openAiServiceEndpoint = process.env.AZURE_OPENAI_SERVICE_ENDPOINT || "";
const openAiKey = process.env.AZURE_OPENAI_SERVICE_KEY || "";
const openAiDeploymentModel = process.env.AZURE_OPENAI_DEPLOYMENT_MODEL_NAME || "";


const answerPromptSystemTemplate = `You are Fargo, Wells Fargo's AI-powered client assistant. You're calling Stacy Dunton — a Partner at PwC in Dallas TX — to follow up on her inquiry about the Autograph Journey vs Autograph card that she made talking to Fargo's web chatbot version on Wellsfargo.com. She started this through the Wells Fargo web chatbot.

GOAL: Help Stacy figure out which card makes sense based on her spending, collect the remaining info needed for an application, and submit it if she's ready.

WHAT YOU KNOW (from her Wells Fargo account data):
- Full legal name, DOB, SSN, home address — all on file
- University of Illinois alum
- High net worth, married
- Already a Wells Fargo banking customer
- From chatbot: deciding between Autograph Journey and Autograph, wants to maximize business travel rewards

WHAT YOU STILL NEED FOR THE APPLICATION:
- Current income range (ask her)
- Confirm she's still employed at PwC (ask her)
- Which card she picks
- Verbal authorization for the credit pull

THE TWO CARDS (know cold):

AUTOGRAPH JOURNEY — $95/yr:
- 5x hotels, 4x airlines, 3x restaurants + other travel, 1x everything else
- 60K bonus points after $4K in 3 months = $600 toward travel
- $50 annual airline credit (effectively $45/yr net fee)
- No foreign transaction fees
- Trip cancellation up to $15K, lost baggage, auto rental coverage
- Cell phone protection up to $1,000
- Transfer 1:1 to British Airways, Air France-KLM, JetBlue, Virgin Atlantic, Avianca, Aer Lingus, Iberia
- 24/7 Visa Signature Concierge

AUTOGRAPH — $0/yr:
- 3x restaurants, travel, gas, transit, streaming, phone plans. 1x everything else
- 20K bonus points after $1K in 3 months = $200 toward travel
- Same transfer partners as Journey
- Cell phone protection up to $600
- 0% intro APR for 12 months
- Won TPG 2026 No-Annual-Fee Card of the Year

BREAKEVEN MATH (have ready):
- Journey costs $45 more after airline credit
- Journey earns 2 extra points per $1 on hotels (5x vs 3x), 1 extra on airlines (4x vs 3x)
- ~$2,000-$3,000 in annual travel spend breaks even
- Anyone spending $5K+ clearly better with Journey
- Welcome bonus alone ($600 vs $200) covers the fee difference for years

THE CALL:

1. OPEN — reference the chatbot:
"This call is being recorded. Hey Stacy! This is Fargo from Wells Fargo — following up on your chat about the Autograph cards. You were looking at the Journey versus the regular Autograph, right? Figured a quick call might be easier than going back and forth."

2. GET HER TRAVEL SPEND:
You need her rough annual spend to give a real recommendation. Ask naturally:
- "So ballpark, it looks like you spend 50k on travel and 20k on dining per year through other Wells Fargo Cards. Does this capture your full spend on these or are you spending more through other cards??"
- Dining too if relevant.
Use her numbers to tell her which card wins.

3. MAKE IT REAL — trips not points:
- "That's enough for a round-trip to Greece in business class through British Airways."
- "Welcome bonus alone gets you and your husband a long weekend somewhere nice."
- "You'd basically be flying domestic free 3-4 times a year."
Frame it in experiences, not multipliers.

4. BREAKEVEN — keep it dead simple:
"The Journey fee is really only $45 after the airline credit. If you're spending even a couple thousand on travel, the extra points cover it easily. And the welcome bonus is $400 more — that alone pays the fee for like 9 years."

5. IF SHE WANTS TO APPLY — collect what you need:
"Awesome. I've got most of your info on file already. Just need a couple quick things — are you still with PwC?"
[Confirm]
"And I see your annual income was last confirmed January 20th 2026 as $500k. Is this correct?"
[Get answer]
"Perfect. Do we have your consent to check your credit report?"
- Once confirmed: "Done — you've been auto-approved, Stacy. Congrats. Email confirmation and a notification in the app coming in the next few minutes. Card shows up in 5 to 7 business days."

6. IF NOT READY:
"No rush at all — want me to send you a side-by-side so you can think it over?"

7. CLOSE:
"Anything else?" If no — "Thanks Stacy, great chatting. Go Illini — take care."

RULES:
- CONCISE. Talk like a human. Don't list every feature — hit what matters for her.
- Ask her to confirm spending to give a real answer.
- Frame rewards as trips and experiences.
- Confirm income range and employment confirmation naturally before submitting — don't make it feel like an interrogation.
- Never repeat back sensitive data.
- If interrupted, listen, respond, continue.
- Illinois only if it flows.
- Don't oversell. Help her decide.

You know that Stacy spends 20k per year on dining, 50k per year on travel and just want to confirm. You also know her income of 500k. You know, but you should still verify.

TONE: Smart friend who knows credit cards. Casual, confident, helpful. Conversation not a pitch.`;

console.log("=== SYSTEM PROMPT LOADED ===");
console.log(`Prompt length: ${answerPromptSystemTemplate.length} characters`);
console.log(`First 100 chars: ${answerPromptSystemTemplate.substring(0, 100)}...`);
console.log("============================\n");

export async function initWebsocket(socket: WebSocket) {
    ws = socket;
    console.log("✅ ACS WebSocket initialized");
}

export async function sendAudioToExternalAi(data: string) {
    try {
        if (realtimeWs && realtimeWs.readyState === WebSocket.OPEN) {
            const message = {
                type: "input_audio_buffer.append",
                audio: data,
            };
            realtimeWs.send(JSON.stringify(message));
        }
    } catch (e) {
        console.error("Error sending audio to OpenAI:", e);
    }
}

export async function startConversation() {
    await startRealtime(openAiServiceEndpoint, openAiKey, openAiDeploymentModel);
}

async function startRealtime(endpoint: string, apiKey: string, deploymentOrModel: string) {
    try {
        console.log("\n=== STARTING REALTIME CONNECTION ===");
        console.log(`Endpoint: ${endpoint}`);
        console.log(`Model: ${deploymentOrModel}`);
        console.log(`API Key present: ${apiKey ? 'YES' : 'NO'}`);
        
        const baseUrl = endpoint.replace(/\/$/, "");
        const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/v1/realtime?model=${deploymentOrModel}`;
        
        console.log(`WebSocket URL: ${wsUrl}`);
        
        realtimeWs = new WebSocket(wsUrl, {
            headers: { 'api-key': apiKey }
        });

        realtimeWs.on('open', () => {
            console.log("\n✅ OpenAI WebSocket connection OPENED");
            console.log("⏳ Waiting for session.created event before configuring...");
        });

        realtimeWs.on('message', async (data: Buffer) => {
            try {
                const message = JSON.parse(data.toString());
                console.log(`\n📨 Received event: ${message.type}`);
                
                // CRITICAL: Only send session.update AFTER session.created
                if (message.type === "session.created") {
                    console.log("\n🎯 SESSION CREATED - Now sending configuration...");
                    console.log(`Session ID: ${message.session?.id}`);
                    
                    // Build the session config
                    const sessionConfig = {
                        type: "session.update",
                        session: {
                            type: "realtime",
                            instructions: answerPromptSystemTemplate,
                            output_modalities: ["audio"],
                            audio: {
                                input: {
                                    transcription: {
                                        model: "whisper-1"
                                    },
                                    format: {
                                        type: "audio/pcm",
                                        rate: 24000
                                    },
                                    turn_detection: {
                                        type: "server_vad",
                                        threshold: 0.5,
                                        prefix_padding_ms: 300,
                                        silence_duration_ms: 200,
                                        create_response: true
                                    }
                                },
                                output: {
                                    voice: "ballad", // or "shimmer", "ash", "ballad", "coral", "sage", "verse"
                                    format: {
                                        type: "audio/pcm",
                                        rate: 24000
                                    }
                                }
                            }
                        }
                    };
                    
                    // CRITICAL LOGGING - Verify instructions are present
                    console.log("\n=== SESSION CONFIG BEING SENT ===");
                    console.log(`Instructions present: ${sessionConfig.session.instructions ? 'YES' : 'NO'}`);
                    console.log(`Instructions length: ${sessionConfig.session.instructions?.length || 0} characters`);
                    console.log(`First 150 chars of instructions: ${sessionConfig.session.instructions?.substring(0, 150)}...`);
                    console.log(`Full config: ${JSON.stringify(sessionConfig, null, 2)}`);
                    console.log("=================================\n");
                    
                    realtimeWs.send(JSON.stringify(sessionConfig));
                    console.log("✅ Session update sent to OpenAI");
                }
                
                // When session is confirmed updated, Tony can initiate the call
                if (message.type === "session.updated") {
                    console.log("\n✅ SESSION UPDATED CONFIRMED");
                    console.log(`Confirmed instructions length: ${message.session?.instructions?.length || 0} characters`);
                    console.log(`Confirmed instructions preview: ${message.session?.instructions?.substring(0, 150)}...`);
                    console.log("🎤 Initiating Tony's greeting...\n");
                    triggerInitialGreeting();
                }

                await handleRealtimeMessages(message);
            } catch (error) {
                console.error('❌ Error parsing message:', error);
            }
        });

        realtimeWs.on('error', (err) => {
            console.error("\n❌ OpenAI WebSocket ERROR:", err);
        });
        
        realtimeWs.on('close', () => {
            console.log("\n🔌 OpenAI WebSocket CLOSED");
        });

    } catch (error) {
        console.error("❌ Error during startRealtime:", error);
    }
}

/**
 * Forces Tony to start the conversation according to the system prompt
 */
function triggerInitialGreeting() {
    console.log("\n=== TRIGGERING INITIAL GREETING ===");
    
    const greetingEvent = {
        type: "conversation.item.create",
        item: {
            type: "message",
            role: "user",
            content: [{
                type: "input_text",
                text: "The person has answered the phone. Introduce yourself and start the TPRM assessment."
            }]
        }
    };
    
    console.log("Sending conversation item:", JSON.stringify(greetingEvent, null, 2));
    realtimeWs.send(JSON.stringify(greetingEvent));
    
    console.log("Requesting response generation...");
    realtimeWs.send(JSON.stringify({ type: "response.create" }));
    
    console.log("✅ Initial greeting triggered\n");
}

async function handleRealtimeMessages(message: any) {
    switch (message.type) {
        case "session.created":
            // Handled above
            break;
            
        case "session.updated":
            // Handled above
            break;
            
        case "response.output_audio_transcript.delta":
            process.stdout.write(message.delta); // Stream transcript in real-time
            break;
            
        case "response.output_audio_transcript.done":
            console.log(`\n🤖 Tony (complete): ${message.transcript}\n`);
            break;
            
        case "response.output_audio.delta":
            // Send audio back to ACS via the media streaming socket
            await receiveAudioForOutbound(message.delta);
            break;
            
        case "input_audio_buffer.speech_started":
            console.log("🎙️  User started speaking (barge-in)");
            stopAudio();
            break;
            
        case "input_audio_buffer.speech_stopped":
            console.log("🎙️  User stopped speaking");
            break;
            
        case "conversation.item.created":
            console.log(`💬 Conversation item created: ${message.item?.type}`);
            break;
            
        case "response.created":
            console.log(`🎯 Response created: ${message.response?.id}`);
            break;
            
        case "response.done":
            console.log(`✅ Response complete: ${message.response?.id}`);
            break;
            
        case "error":
            console.error("\n❌ OpenAI ERROR Event:");
            console.error(`  Code: ${message.error?.code}`);
            console.error(`  Message: ${message.error?.message}`);
            console.error(`  Type: ${message.error?.type}`);
            console.error(`  Full error:`, JSON.stringify(message.error, null, 2));
            break;
            
        default:
            console.log(`📝 Unhandled event type: ${message.type}`);
    }
}

// --- ACS Audio Handling ---

async function receiveAudioForOutbound(data: string) {
    try {
        const jsonData = createOutboundAudioData(data);
        sendMessageToAcs(jsonData);
    } catch (e) {
        console.error("Error creating outbound audio:", e);
    }
}

async function stopAudio() {
    try {
        const jsonData = createOutboundStopAudioData();
        sendMessageToAcs(jsonData);
        console.log("🛑 Audio playback stopped");
    } catch (e) {
        console.error("Error stopping audio:", e);
    }
}

async function sendMessageToAcs(data: string) {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(data);
    } else {
        console.warn("⚠️  Cannot send to ACS - WebSocket not open");
    }
}