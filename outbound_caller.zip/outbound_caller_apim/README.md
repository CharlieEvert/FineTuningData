# Outbound Caller — ACS + Azure OpenAI Realtime Voice Agent

AI voice calling agent built on Azure Communication Services and Azure OpenAI Realtime. Designed for **enterprise internal deployment** — the application server has no public internet exposure. All traffic routes through Azure API Management.

---

## Architecture

```
                        ┌─────────────────────────────────────────┐
                        │              Azure VNet                  │
                        │                                          │
  Internet / ACS ──────▶│  APIM (External)  ──▶  Container App   │
  Enterprise clients    │  (public IP)           (internal only)  │
                        │                              │           │
                        └──────────────────────────────┼──────────┘
                                                        │
                                              Azure OpenAI Realtime
                                              (outbound from VNet)
```

- **Container App** — runs with internal ingress only. No public IP. Unreachable from the internet directly.
- **APIM** — the only public-facing endpoint. Enforces API key auth on client-facing routes. Passes ACS webhook callbacks through unauthenticated (ACS is a trusted Microsoft service).
- **VNet** — both APIM and the Container Apps environment live inside it. Internal traffic stays on the private network.
- **ACS callbacks** — ACS posts call events to APIM's public URL, which forwards them to the Container App internally.
- **WebSocket (media streaming)** — ACS connects to the WebSocket URL (derived from CALLBACK_URI = APIM URL), which APIM proxies to the Container App.

---

## Prerequisites

- [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli) — `az` in your PATH
- An Azure subscription with Owner or Contributor + User Access Administrator roles
- Azure Communication Services resource with a phone number
- Azure OpenAI or Azure AI Foundry resource with a `gpt-realtime` deployment

No local Docker required — `az acr build` builds in Azure.

---

## Getting your credentials

### Azure Communication Services
1. Azure Portal → your ACS resource → **Keys** → copy **Connection String** → `ACS_CONNECTION_STRING`
2. ACS resource → **Phone Numbers** → copy your number → `ACS_PHONE_NUMBER`

### Azure OpenAI / Azure AI Foundry

| Resource type | Endpoint format |
|---|---|
| Azure OpenAI resource | `https://your-resource.openai.azure.com` |
| Azure AI Foundry resource | `https://your-resource.services.ai.azure.com` |

**From Azure AI Foundry ([ai.azure.com](https://ai.azure.com)):**
1. Your project → **Models + endpoints** → click your deployment
2. Copy Target URI → `AZURE_OPENAI_ENDPOINT`
3. Copy Key → `AZURE_OPENAI_KEY`
4. Copy deployment name → `AZURE_OPENAI_DEPLOYMENT`

### gpt-realtime (GA) vs gpt-4o-realtime-preview

This app uses the GA WebSocket format. If you deployed `gpt-4o-realtime-preview`, update one line in `src/azureOpenAiService.ts`:

```typescript
// Replace:
const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/v1/realtime?model=${deploymentOrModel}`;
// With:
const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/realtime?api-version=2025-04-01-preview&deployment=${deploymentOrModel}`;
```

---

## Deployment

### 1. Configure deploy.sh

Open `deploy.sh` and fill in the config block at the top:

```bash
# ── EDIT THIS BLOCK ───────────────────────────────────────────────────────────
RESOURCE_GROUP="outbound-caller-rg"
LOCATION="eastus"                         # eastus2 recommended for gpt-realtime latency

ACR_NAME="outboundcalleracr"              # globally unique, lowercase, no hyphens
APP_NAME="outbound-caller"
CONTAINER_ENV_NAME="outbound-caller-env"
IMAGE_NAME="outbound-caller"

APIM_NAME="outbound-caller-apim"          # globally unique
APIM_PUBLISHER_EMAIL="admin@yourcompany.com"
APIM_PUBLISHER_ORG="Your Company"
APIM_SKU="Developer"                      # Developer (no SLA) | Premium (prod, VNet, SLA)

VNET_NAME="outbound-caller-vnet"
SUBNET_APIM="apim-subnet"
SUBNET_ACA="aca-subnet"

# ── SECRETS ───────────────────────────────────────────────────────────────────
ACS_CONNECTION_STRING="your-acs-connection-string"
ACS_PHONE_NUMBER="+1XXXXXXXXXX"
AZURE_OPENAI_KEY="your-openai-key"
AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com"
AZURE_OPENAI_DEPLOYMENT="gpt-realtime"
```

### APIM SKU — Developer vs Premium

| SKU | Cost | VNet support | SLA | Use for |
|---|---|---|---|---|
| Developer | ~$50/mo | External VNet ✅ | ❌ | Testing, internal tools |
| Premium | ~$3,000/mo | Internal + External VNet ✅ | ✅ 99.95% | Production |

`Developer` is fine for enterprise internal tools where you control availability expectations. Use `Premium` if you need the SLA or want fully internal APIM (no public IP at all).

### 2. Run the deploy script

```bash
bash deploy.sh
```

The script runs all steps in order:
1. Azure login check
2. Resource group
3. VNet + subnets (APIM subnet + Container Apps subnet)
4. Container Registry + build/push Docker image
5. Container Apps environment (VNet-integrated, internal only)
6. Container App (internal ingress, placeholder CALLBACK_URI)
7. APIM instance (**takes 30–45 minutes on first run**)
8. APIM API, routes, auth policies, product, subscription
9. Update CALLBACK_URI on the Container App to the APIM public URL
10. Print summary with API key and example commands

The script is **idempotent** — re-running it skips resources that already exist (particularly APIM).

### 3. Register the ACS EventGrid webhook

After deploy completes, register the inbound call webhook:

1. Azure Portal → your ACS resource → **Events** → **+ Event Subscription**
2. Event type: `IncomingCall`
3. Endpoint URL: `https://YOUR_APIM_URL/api/incomingCall`
4. Save — the server handles the validation handshake automatically

---

## Redeploying after code changes

```bash
bash redeploy.sh
```

Rebuilds the image in ACR and updates the Container App. APIM, VNet, and all infrastructure are untouched.

---

## Tearing down

```bash
bash teardown.sh
```

Prompts for confirmation, then deletes the entire resource group and everything in it.

---

## API reference

All client-facing routes require the `Ocp-Apim-Subscription-Key` header. ACS webhook routes (`/api/incomingCall`, `/api/callbacks/*`) are unauthenticated — ACS posts to these directly.

### `POST /api/call` — Outbound call

```bash
curl -X POST https://YOUR_APIM_URL/api/call \
  -H "Content-Type: application/json" \
  -H "Ocp-Apim-Subscription-Key: YOUR_KEY" \
  -d '{
    "phoneNumber": "+12345678901",
    "prompt": "You are a helpful assistant...",
    "voice": "shimmer",
    "silenceDurationMs": 300
  }'
```

| Field | Type | Default | Description |
|---|---|---|---|
| `phoneNumber` | string | **required** | E.164 format e.g. `+12345678901` |
| `prompt` | string | built-in default | Full system prompt override |
| `voice` | string | `verse` | `alloy`, `ash`, `ballad`, `coral`, `echo`, `fable`, `onyx`, `nova`, `sage`, `shimmer`, `verse` |
| `silenceDurationMs` | number | `200` | Silence (ms) before AI responds |
| `prefixPaddingMs` | number | `300` | Audio padding before speech detection (ms) |
| `vadThreshold` | number | `0.5` | Voice activity sensitivity 0.0–1.0 |
| `temperature` | number | `0.8` | Response randomness 0.0–1.0 |
| `maxResponseTokens` | number | `4096` | Max tokens per AI turn |
| `greetingMessage` | string | default trigger | Text that kicks off the AI's opening line |

### `POST /api/inbound/config` — Configure inbound line

Sets the AI configuration for all future inbound calls. Persists until changed or server restarts.

```bash
curl -X POST https://YOUR_APIM_URL/api/inbound/config \
  -H "Content-Type: application/json" \
  -H "Ocp-Apim-Subscription-Key: YOUR_KEY" \
  -d '{
    "prompt": "You are a support agent for Acme Corp...",
    "voice": "alloy",
    "silenceDurationMs": 300
  }'
```

### `GET /api/inbound/config` — View inbound config

```bash
curl https://YOUR_APIM_URL/api/inbound/config \
  -H "Ocp-Apim-Subscription-Key: YOUR_KEY"
```

### `DELETE /api/inbound/config` — Reset inbound config

```bash
curl -X DELETE https://YOUR_APIM_URL/api/inbound/config \
  -H "Ocp-Apim-Subscription-Key: YOUR_KEY"
```

---

## Issuing API keys per enterprise client

Each client gets their own subscription key. You can revoke individual keys without affecting others.

```bash
# Create a key for Acme Corp
az apim subscription create \
  --service-name outbound-caller-apim \
  --resource-group outbound-caller-rg \
  --subscription-id client-acme \
  --display-name "Acme Corp" \
  --scope "/products/voice-agent"

# Get Acme's key
az apim subscription show \
  --service-name outbound-caller-apim \
  --resource-group outbound-caller-rg \
  --sid client-acme \
  --query primaryKey -o tsv

# Revoke Acme's access
az apim subscription delete \
  --service-name outbound-caller-apim \
  --resource-group outbound-caller-rg \
  --sid client-acme
```

---

## Running locally

Local dev uses a dev tunnel instead of APIM — simpler for iteration.

### 1. Install and start a dev tunnel

```bash
devtunnel create --allow-anonymous
devtunnel port create -p 8080
devtunnel host
```

Copy the tunnel URL into `CALLBACK_URI` in your `.env`.

### 2. Set up .env

```bash
cp .env.example .env
# Fill in all values
```

### 3. Start the server

```bash
npm install
npm run dev
```

### 4. Place a call

```bash
# Terminal prompt
call +12345678901

# Or HTTP (no auth needed locally)
curl -X POST http://localhost:8080/api/call \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+12345678901"}'
```

---

## Project structure

```
outbound_caller/
├── deploy.sh                  ← full infrastructure deploy (run once)
├── redeploy.sh                ← push code changes to existing deploy
├── teardown.sh                ← delete all Azure resources
├── Dockerfile
├── .dockerignore
├── .env.example
├── package.json
├── tsconfig.json
└── src/
    ├── app.ts                 ← Express server, ACS client, HTTP endpoints, WebSocket server
    ├── azureOpenAiService.ts  ← OpenAI Realtime connection, session config, reconnect
    └── mediaStreamingHandler.ts ← ACS audio packet parsing
```

---

## Troubleshooting

| Problem | What to check |
|---|---|
| APIM deploy stuck | Normal — first provision takes 30–45 min. Check: `az apim show --name YOUR_APIM --resource-group YOUR_RG --query properties.provisioningState -o tsv` |
| 401 from APIM | Missing or wrong `Ocp-Apim-Subscription-Key` header |
| 404 from APIM | Route not registered. Re-run `configure_apim_api()` section of deploy.sh |
| Call connects but AI silent | CALLBACK_URI is wrong. Verify it equals the APIM public URL: `az containerapp show --name outbound-caller --resource-group outbound-caller-rg --query "properties.template.containers[0].env[?name=='CALLBACK_URI'].value" -o tsv` |
| ACS EventGrid validation failing | Server must be running and APIM URL must be reachable before registering the webhook |
| OpenAI 401 | Wrong key. Check `AZURE_OPENAI_KEY` env var on the Container App |
| OpenAI 404 | Wrong deployment name or endpoint. Check GA vs preview WebSocket format |
| Container App not reachable from APIM | Both must be in the same VNet. Check subnet IDs and Container Apps environment `--internal-only true` flag |
| Logs | `az containerapp logs show --name outbound-caller --resource-group outbound-caller-rg --follow` |
