#!/bin/bash
set -euo pipefail

# =============================================================================
# deploy.sh — ACS + OpenAI Realtime Voice Agent
# Architecture: Container App (internal, VNet) → APIM (public gateway)
#
# APIM acts as the only public-facing endpoint:
#   - Enforces API key auth on /api/call and /api/inbound/* routes
#   - Passes ACS callbacks (/api/incomingCall, /api/callbacks/*) through unauthenticated
#     (ACS is a trusted Microsoft service; these don't need user-facing auth)
#   - Proxies WebSocket upgrade for media streaming
#
# Run: bash deploy.sh
# Requires: az CLI, Docker (for local builds — not needed here, acr build handles it)
# =============================================================================

# ── EDIT THIS BLOCK ───────────────────────────────────────────────────────────
RESOURCE_GROUP="outbound-caller-rg"
LOCATION="eastus"                          # eastus2 recommended for gpt-realtime latency

ACR_NAME="outboundcalleracr"               # globally unique, lowercase, no hyphens, max 50 chars
APP_NAME="outbound-caller"
CONTAINER_ENV_NAME="outbound-caller-env"
IMAGE_NAME="outbound-caller"

APIM_NAME="outbound-caller-apim"           # globally unique
APIM_PUBLISHER_EMAIL="admin@yourcompany.com"
APIM_PUBLISHER_ORG="Your Company"
APIM_SKU="Developer"                       # Developer (no SLA, cheap) | Premium (prod, SLA, ~$3k/mo)
                                            # Use Developer for testing, Premium for production VNet support

VNET_NAME="outbound-caller-vnet"
SUBNET_APIM="apim-subnet"
SUBNET_ACA="aca-subnet"

# ── SECRETS — EDIT THESE ─────────────────────────────────────────────────────
ACS_CONNECTION_STRING="your-acs-connection-string"
ACS_PHONE_NUMBER="+1XXXXXXXXXX"
AZURE_OPENAI_KEY="your-openai-key"
AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com"
AZURE_OPENAI_DEPLOYMENT="gpt-realtime"
# ─────────────────────────────────────────────────────────────────────────────

# ── Internal state (do not edit) ─────────────────────────────────────────────
APIM_API_ID="voice-agent-api"
SUBSCRIPTION_ID=""
CONTAINER_APP_INTERNAL_URL=""
APIM_PUBLIC_URL=""

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

step() { echo ""; echo "▶ $1"; }
ok()   { echo "✅ $1"; }
info() { echo "   $1"; }

banner() {
  echo ""
  echo "╔══════════════════════════════════════════════════════════════╗"
  echo "║        ACS + OpenAI Realtime Voice Agent — Deployer         ║"
  echo "║               Container Apps + APIM + VNet                  ║"
  echo "╚══════════════════════════════════════════════════════════════╝"
  echo ""
}

# ─────────────────────────────────────────────────────────────────────────────
# 1. Login + subscription
# ─────────────────────────────────────────────────────────────────────────────

login() {
  step "Checking Azure login..."
  az account show > /dev/null 2>&1 || { echo "Not logged in — running az login..."; az login; }
  SUBSCRIPTION_ID=$(az account show --query id -o tsv)
  ok "Logged in — subscription: $SUBSCRIPTION_ID"
}

# ─────────────────────────────────────────────────────────────────────────────
# 2. Resource group
# ─────────────────────────────────────────────────────────────────────────────

create_resource_group() {
  step "Creating resource group: $RESOURCE_GROUP ($LOCATION)..."
  az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none
  ok "Resource group ready"
}

# ─────────────────────────────────────────────────────────────────────────────
# 3. VNet + subnets
#
# Address space: 10.0.0.0/16
#   apim-subnet:  10.0.0.0/27  — minimum /29 required for APIM Developer SKU
#   aca-subnet:   10.0.1.0/23  — Container Apps needs /23 minimum
# ─────────────────────────────────────────────────────────────────────────────

create_vnet() {
  step "Creating VNet: $VNET_NAME..."
  az network vnet create \
    --name "$VNET_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --address-prefix "10.0.0.0/16" \
    --output none
  ok "VNet created"

  step "Creating APIM subnet (10.0.0.0/27)..."
  az network vnet subnet create \
    --name "$SUBNET_APIM" \
    --resource-group "$RESOURCE_GROUP" \
    --vnet-name "$VNET_NAME" \
    --address-prefix "10.0.0.0/27" \
    --output none
  ok "APIM subnet ready"

  step "Creating Container Apps subnet (10.0.1.0/23)..."
  az network vnet subnet create \
    --name "$SUBNET_ACA" \
    --resource-group "$RESOURCE_GROUP" \
    --vnet-name "$VNET_NAME" \
    --address-prefix "10.0.1.0/23" \
    --output none
  ok "ACA subnet ready"
}

# ─────────────────────────────────────────────────────────────────────────────
# 4. Container Registry + build image
# ─────────────────────────────────────────────────────────────────────────────

build_image() {
  step "Creating Container Registry: $ACR_NAME..."
  az acr create \
    --name "$ACR_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --sku Basic \
    --admin-enabled true \
    --output none
  ok "Registry created"

  step "Building and pushing Docker image (runs in Azure — no local Docker needed)..."
  az acr build \
    --registry "$ACR_NAME" \
    --image "${IMAGE_NAME}:latest" \
    .
  ok "Image built and pushed: ${ACR_NAME}.azurecr.io/${IMAGE_NAME}:latest"
}

# ─────────────────────────────────────────────────────────────────────────────
# 5. Container Apps environment (VNet-integrated, internal only)
# ─────────────────────────────────────────────────────────────────────────────

create_container_env() {
  step "Creating Container Apps environment (internal, VNet-integrated)..."
  local ACA_SUBNET_ID
  ACA_SUBNET_ID=$(az network vnet subnet show \
    --name "$SUBNET_ACA" \
    --resource-group "$RESOURCE_GROUP" \
    --vnet-name "$VNET_NAME" \
    --query id -o tsv)

  az containerapp env create \
    --name "$CONTAINER_ENV_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --infrastructure-subnet-resource-id "$ACA_SUBNET_ID" \
    --internal-only true \
    --output none
  ok "Container Apps environment ready (internal only)"
}

# ─────────────────────────────────────────────────────────────────────────────
# 6. Container App (internal ingress)
#    CALLBACK_URI uses a placeholder — updated after APIM is deployed
# ─────────────────────────────────────────────────────────────────────────────

deploy_container_app() {
  step "Deploying Container App: $APP_NAME (internal ingress)..."
  az containerapp create \
    --name "$APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --environment "$CONTAINER_ENV_NAME" \
    --image "${ACR_NAME}.azurecr.io/${IMAGE_NAME}:latest" \
    --registry-server "${ACR_NAME}.azurecr.io" \
    --ingress internal \
    --target-port 8080 \
    --min-replicas 1 \
    --max-replicas 3 \
    --env-vars \
      PORT=8080 \
      "CONNECTION_STRING=${ACS_CONNECTION_STRING}" \
      "ACS_PHONE_NUMBER=${ACS_PHONE_NUMBER}" \
      "AZURE_OPENAI_SERVICE_KEY=${AZURE_OPENAI_KEY}" \
      "AZURE_OPENAI_SERVICE_ENDPOINT=${AZURE_OPENAI_ENDPOINT}" \
      "AZURE_OPENAI_DEPLOYMENT_MODEL_NAME=${AZURE_OPENAI_DEPLOYMENT}" \
      "CALLBACK_URI=https://placeholder" \
    --output none

  CONTAINER_APP_INTERNAL_URL=$(az containerapp show \
    --name "$APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query properties.configuration.ingress.fqdn -o tsv)

  ok "Container App deployed — internal URL: https://${CONTAINER_APP_INTERNAL_URL}"
}

# ─────────────────────────────────────────────────────────────────────────────
# 7. APIM instance
#    NOTE: APIM provisioning takes 30–45 minutes on first deploy. Script waits.
#    Subsequent runs skip creation if APIM already exists.
# ─────────────────────────────────────────────────────────────────────────────

create_apim() {
  step "Checking if APIM already exists..."
  local EXISTS
  EXISTS=$(az apim show --name "$APIM_NAME" --resource-group "$RESOURCE_GROUP" --query name -o tsv 2>/dev/null || echo "")

  if [[ -n "$EXISTS" ]]; then
    ok "APIM already exists — skipping creation"
  else
    step "Creating APIM: $APIM_NAME (SKU: $APIM_SKU)..."
    info "⏳ This takes 30–45 minutes on first deploy. Grab a coffee."

    local APIM_SUBNET_ID
    APIM_SUBNET_ID=$(az network vnet subnet show \
      --name "$SUBNET_APIM" \
      --resource-group "$RESOURCE_GROUP" \
      --vnet-name "$VNET_NAME" \
      --query id -o tsv)

    az apim create \
      --name "$APIM_NAME" \
      --resource-group "$RESOURCE_GROUP" \
      --location "$LOCATION" \
      --publisher-email "$APIM_PUBLISHER_EMAIL" \
      --publisher-name "$APIM_PUBLISHER_ORG" \
      --sku-name "$APIM_SKU" \
      --virtual-network-type "External" \
      --virtual-network "$APIM_SUBNET_ID" \
      --output none

    ok "APIM created"
  fi

  APIM_PUBLIC_URL="https://$(az apim show \
    --name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query gatewayUrl -o tsv)"

  ok "APIM gateway URL: $APIM_PUBLIC_URL"
}

# ─────────────────────────────────────────────────────────────────────────────
# 8. APIM API + operations + policies
#
# Routes:
#   POST   /api/call                → requires Ocp-Apim-Subscription-Key header
#   POST   /api/inbound/config      → requires Ocp-Apim-Subscription-Key header
#   GET    /api/inbound/config      → requires Ocp-Apim-Subscription-Key header
#   DELETE /api/inbound/config      → requires Ocp-Apim-Subscription-Key header
#   POST   /api/incomingCall        → no auth (ACS EventGrid webhook)
#   POST   /api/callbacks/{id}      → no auth (ACS callback)
#
# Policy strips the subscription key header before forwarding to backend
# so it never reaches the Container App.
# ─────────────────────────────────────────────────────────────────────────────

configure_apim_api() {
  step "Configuring APIM API and routes..."

  local BACKEND_URL="https://${CONTAINER_APP_INTERNAL_URL}"

  # ── Create the API ──────────────────────────────────────────────────────────
  az apim api create \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --api-id "$APIM_API_ID" \
    --display-name "Voice Agent API" \
    --path "/" \
    --protocols https \
    --service-url "$BACKEND_URL" \
    --subscription-required false \
    --output none

  ok "API created"

  # ── Global inbound policy: forward to backend, strip subscription key ───────
  # Applied at API level so all operations inherit it
  local GLOBAL_POLICY='<policies>
  <inbound>
    <base />
    <set-header name="Ocp-Apim-Subscription-Key" exists-action="delete" />
  </inbound>
  <backend><base /></backend>
  <outbound><base /></outbound>
  <on-error><base /></on-error>
</policies>'

  az apim api policy create \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --api-id "$APIM_API_ID" \
    --value "$GLOBAL_POLICY" \
    --output none

  # ── Auth policy (applied to authenticated operations) ──────────────────────
  # Validates Ocp-Apim-Subscription-Key; returns 401 if missing/invalid
  local AUTH_POLICY='<policies>
  <inbound>
    <base />
    <choose>
      <when condition="@(context.Subscription == null)">
        <return-response>
          <set-status code="401" reason="Unauthorized" />
          <set-header name="WWW-Authenticate" exists-action="override">
            <value>ApiKey realm="Voice Agent API"</value>
          </set-header>
          <set-body>{"error": "API key required. Pass Ocp-Apim-Subscription-Key header."}</set-body>
        </return-response>
      </when>
    </choose>
  </inbound>
  <backend><base /></backend>
  <outbound><base /></outbound>
  <on-error><base /></on-error>
</policies>'

  # ── Helper: create operation ────────────────────────────────────────────────
  create_operation() {
    local OP_ID=$1 METHOD=$2 URL_TEMPLATE=$3 DISPLAY=$4 AUTH=$5

    az apim api operation create \
      --service-name "$APIM_NAME" \
      --resource-group "$RESOURCE_GROUP" \
      --api-id "$APIM_API_ID" \
      --operation-id "$OP_ID" \
      --display-name "$DISPLAY" \
      --method "$METHOD" \
      --url-template "$URL_TEMPLATE" \
      --output none

    if [[ "$AUTH" == "true" ]]; then
      az apim api operation policy create \
        --service-name "$APIM_NAME" \
        --resource-group "$RESOURCE_GROUP" \
        --api-id "$APIM_API_ID" \
        --operation-id "$OP_ID" \
        --value "$AUTH_POLICY" \
        --output none
    fi
  }

  # Authenticated routes (enterprise API clients)
  create_operation "post-call"            "POST"   "/api/call"             "Place Outbound Call"        "true"
  create_operation "post-inbound-config"  "POST"   "/api/inbound/config"   "Set Inbound Config"         "true"
  create_operation "get-inbound-config"   "GET"    "/api/inbound/config"   "Get Inbound Config"         "true"
  create_operation "del-inbound-config"   "DELETE" "/api/inbound/config"   "Reset Inbound Config"       "true"

  # Unauthenticated routes (ACS EventGrid + callback system)
  create_operation "acs-incoming-call"    "POST"   "/api/incomingCall"     "ACS Incoming Call Webhook"  "false"
  create_operation "acs-callback"         "POST"   "/api/callbacks/{id}"   "ACS Call Callback"          "false"

  ok "API routes configured"

  # ── Create a default product and subscription ───────────────────────────────
  step "Creating APIM product and default subscription..."

  az apim product create \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --product-id "voice-agent" \
    --product-name "Voice Agent" \
    --description "Access to the Voice Agent API" \
    --subscription-required true \
    --approval-required false \
    --state "published" \
    --output none

  az apim product api add \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --product-id "voice-agent" \
    --api-id "$APIM_API_ID" \
    --output none

  # Create a named subscription and capture its key
  az apim subscription create \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --subscription-id "default-subscription" \
    --display-name "Default Subscription" \
    --scope "/products/voice-agent" \
    --output none

  ok "Product and subscription created"
}

# ─────────────────────────────────────────────────────────────────────────────
# 9. Update CALLBACK_URI on the Container App to the APIM public URL
#    ACS will POST events to APIM, which forwards them to the Container App
# ─────────────────────────────────────────────────────────────────────────────

update_callback_uri() {
  step "Updating CALLBACK_URI on Container App to APIM URL: $APIM_PUBLIC_URL..."
  az containerapp update \
    --name "$APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --set-env-vars "CALLBACK_URI=${APIM_PUBLIC_URL}" \
    --output none
  ok "CALLBACK_URI updated"
}

# ─────────────────────────────────────────────────────────────────────────────
# 10. Fetch the API subscription key
# ─────────────────────────────────────────────────────────────────────────────

fetch_api_key() {
  step "Fetching API subscription key..."
  API_KEY=$(az apim subscription show \
    --service-name "$APIM_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --sid "default-subscription" \
    --query primaryKey -o tsv 2>/dev/null || echo "")

  if [[ -z "$API_KEY" ]]; then
    API_KEY="(run: az apim subscription show --service-name $APIM_NAME --resource-group $RESOURCE_GROUP --sid default-subscription --query primaryKey -o tsv)"
  fi
}

# ─────────────────────────────────────────────────────────────────────────────
# 11. Done banner
# ─────────────────────────────────────────────────────────────────────────────

print_summary() {
  echo ""
  echo "╔══════════════════════════════════════════════════════════════════════════╗"
  echo "║                         DEPLOYMENT COMPLETE ✅                          ║"
  echo "╠══════════════════════════════════════════════════════════════════════════╣"
  printf "║  APIM Gateway:     %-53s ║\n" "$APIM_PUBLIC_URL"
  printf "║  Container App:    %-53s ║\n" "https://${CONTAINER_APP_INTERNAL_URL} (internal)"
  printf "║  API Key:          %-53s ║\n" "$API_KEY"
  echo "╠══════════════════════════════════════════════════════════════════════════╣"
  echo "║  Register this URL as your ACS EventGrid webhook:                       ║"
  printf "║    %-70s ║\n" "${APIM_PUBLIC_URL}/api/incomingCall"
  echo "╠══════════════════════════════════════════════════════════════════════════╣"
  echo "║  Place an outbound call:                                                ║"
  echo "║    curl -X POST ${APIM_PUBLIC_URL}/api/call \\"
  echo "║      -H 'Content-Type: application/json' \\"
  echo "║      -H 'Ocp-Apim-Subscription-Key: YOUR_API_KEY' \\"
  echo "║      -d '{\"phoneNumber\": \"+12345678901\"}'                              ║"
  echo "╠══════════════════════════════════════════════════════════════════════════╣"
  echo "║  Configure inbound line:                                                ║"
  echo "║    curl -X POST ${APIM_PUBLIC_URL}/api/inbound/config \\"
  echo "║      -H 'Content-Type: application/json' \\"
  echo "║      -H 'Ocp-Apim-Subscription-Key: YOUR_API_KEY' \\"
  echo "║      -d '{\"prompt\": \"You are...\", \"voice\": \"alloy\"}'                   ║"
  echo "╠══════════════════════════════════════════════════════════════════════════╣"
  echo "║  To issue additional API keys (per enterprise client):                  ║"
  echo "║    az apim subscription create \\"
  echo "║      --service-name $APIM_NAME \\"
  echo "║      --resource-group $RESOURCE_GROUP \\"
  echo "║      --subscription-id client-acme \\"
  echo "║      --display-name 'Acme Corp' \\"
  echo "║      --scope '/products/voice-agent'                                    ║"
  echo "╚══════════════════════════════════════════════════════════════════════════╝"
}

# ─────────────────────────────────────────────────────────────────────────────
# Run all steps
# ─────────────────────────────────────────────────────────────────────────────

banner
login
create_resource_group
create_vnet
build_image
create_container_env
deploy_container_app
create_apim
configure_apim_api
update_callback_uri
fetch_api_key
print_summary
