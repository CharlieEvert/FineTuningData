#!/bin/bash
set -euo pipefail

# =============================================================================
# teardown.sh — Delete all Azure resources created by deploy.sh
# WARNING: This is irreversible. All resources will be permanently deleted.
# =============================================================================

RESOURCE_GROUP="outbound-caller-rg"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║           ⚠️  TEARDOWN WARNING  ⚠️            ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "This will permanently delete resource group: $RESOURCE_GROUP"
echo "and ALL resources inside it (APIM, Container App, VNet, ACR, etc.)"
echo ""
read -rp "Type the resource group name to confirm: " CONFIRM

if [[ "$CONFIRM" != "$RESOURCE_GROUP" ]]; then
  echo "❌ Confirmation mismatch — aborting"
  exit 1
fi

echo ""
echo "▶ Checking Azure login..."
az account show > /dev/null 2>&1 || az login

echo ""
echo "▶ Deleting resource group $RESOURCE_GROUP..."
az group delete --name "$RESOURCE_GROUP" --yes --no-wait
echo "✅ Deletion initiated (runs in background — takes a few minutes)"
echo "   Monitor: az group show --name $RESOURCE_GROUP --query properties.provisioningState -o tsv"
