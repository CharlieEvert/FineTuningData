#!/bin/bash
set -euo pipefail

# =============================================================================
# redeploy.sh — Push code changes to existing deployment
# Run after making code changes: bash redeploy.sh
# =============================================================================

# ── Must match deploy.sh ──────────────────────────────────────────────────────
RESOURCE_GROUP="outbound-caller-rg"
ACR_NAME="outboundcalleracr"
APP_NAME="outbound-caller"
IMAGE_NAME="outbound-caller"
# ─────────────────────────────────────────────────────────────────────────────

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║           Redeploying Voice Agent            ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

echo "▶ Checking Azure login..."
az account show > /dev/null 2>&1 || az login

echo ""
echo "▶ Building and pushing new image..."
az acr build \
  --registry "$ACR_NAME" \
  --image "${IMAGE_NAME}:latest" \
  .
echo "✅ Image pushed"

echo ""
echo "▶ Updating Container App to pull new image..."
az containerapp update \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --image "${ACR_NAME}.azurecr.io/${IMAGE_NAME}:latest" \
  --output none
echo "✅ Container App updated"

echo ""
echo "▶ Fetching revision status..."
az containerapp revision list \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --query "[].{Revision:name, State:properties.runningState, Created:properties.createdTime}" \
  --output table

echo ""
echo "✅ Redeploy complete"
