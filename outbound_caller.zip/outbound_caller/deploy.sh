#!/bin/bash
set -e

# ─────────────────────────────────────────────────────────────────────────────
# deploy.sh — Build and deploy outbound_caller to Azure Container Apps
# Run from inside the outbound_caller/ directory: bash deploy.sh
# ─────────────────────────────────────────────────────────────────────────────

# ── Config — edit these ───────────────────────────────────────────────────────
RESOURCE_GROUP="outbound-caller-rg"
LOCATION="eastus"
ACR_NAME="outboundcallerregistry"   # globally unique, lowercase, no hyphens
APP_NAME="outbound-caller"
ENV_NAME="outbound-caller-env"
IMAGE_NAME="outbound-caller"

# ── Secrets — edit these ─────────────────────────────────────────────────────
CONNECTION_STRING="your-acs-connection-string"
ACS_PHONE_NUMBER="+1XXXXXXXXXX"
AZURE_OPENAI_SERVICE_KEY="your-openai-key"
AZURE_OPENAI_SERVICE_ENDPOINT="https://your-resource.openai.azure.com"
AZURE_OPENAI_DEPLOYMENT_MODEL_NAME="gpt-realtime"
# ─────────────────────────────────────────────────────────────────────────────

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║      ACS + OpenAI Realtime Voice Deployer    ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

echo "▶ Checking Azure login..."
az account show > /dev/null 2>&1 || { echo "Not logged in. Running az login..."; az login; }
echo "✅ Logged in"

echo ""
echo "▶ Creating resource group: $RESOURCE_GROUP in $LOCATION..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none
echo "✅ Resource group ready"

echo ""
echo "▶ Creating Container Registry: $ACR_NAME..."
az acr create \
  --name "$ACR_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --sku Basic \
  --admin-enabled true \
  --output none
echo "✅ Registry ready"

echo ""
echo "▶ Building and pushing Docker image..."
az acr build \
  --registry "$ACR_NAME" \
  --image "${IMAGE_NAME}:latest" \
  .
echo "✅ Image built and pushed"

echo ""
echo "▶ Creating Container Apps environment: $ENV_NAME..."
az containerapp env create \
  --name "$ENV_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --output none
echo "✅ Environment ready"

echo ""
echo "▶ Deploying container app: $APP_NAME..."
az containerapp create \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --environment "$ENV_NAME" \
  --image "${ACR_NAME}.azurecr.io/${IMAGE_NAME}:latest" \
  --registry-server "${ACR_NAME}.azurecr.io" \
  --ingress external \
  --target-port 8080 \
  --min-replicas 1 \
  --max-replicas 1 \
  --env-vars \
    PORT=8080 \
    "CONNECTION_STRING=${CONNECTION_STRING}" \
    "ACS_PHONE_NUMBER=${ACS_PHONE_NUMBER}" \
    "AZURE_OPENAI_SERVICE_KEY=${AZURE_OPENAI_SERVICE_KEY}" \
    "AZURE_OPENAI_SERVICE_ENDPOINT=${AZURE_OPENAI_SERVICE_ENDPOINT}" \
    "AZURE_OPENAI_DEPLOYMENT_MODEL_NAME=${AZURE_OPENAI_DEPLOYMENT_MODEL_NAME}" \
    "CALLBACK_URI=https://placeholder" \
  --output none
echo "✅ App deployed"

echo ""
echo "▶ Fetching public URL..."
FQDN=$(az containerapp show \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --query properties.configuration.ingress.fqdn \
  --output tsv)
PUBLIC_URL="https://${FQDN}"
echo "✅ Public URL: $PUBLIC_URL"

echo ""
echo "▶ Updating CALLBACK_URI to real URL..."
az containerapp update \
  --name "$APP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --set-env-vars "CALLBACK_URI=${PUBLIC_URL}" \
  --output none
echo "✅ CALLBACK_URI updated"

echo ""
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║                        DEPLOYMENT COMPLETE                          ║"
echo "╠══════════════════════════════════════════════════════════════════════╣"
printf  "║  App URL: %-60s ║\n" "$PUBLIC_URL"
echo "╠══════════════════════════════════════════════════════════════════════╣"
echo "║  Next steps:                                                         ║"
echo "║                                                                      ║"
echo "║  1. Register ACS EventGrid webhook (for inbound calls):              ║"
printf  "║     %-67s ║\n" "${PUBLIC_URL}/api/incomingCall"
echo "║                                                                      ║"
echo "║  2. Place an outbound call:                                          ║"
printf  "║     curl -X POST %s/api/call \\\\ ║\n" "$PUBLIC_URL"
echo "║       -H 'Content-Type: application/json' \\"
echo "║       -d '{\"phoneNumber\": \"+12345678901\"}'                           ║"
echo "║                                                                      ║"
echo "║  3. Configure inbound line:                                          ║"
printf  "║     curl -X POST %s/api/inbound/config \\\\ ║\n" "$PUBLIC_URL"
echo "║       -H 'Content-Type: application/json' \\"
echo "║       -d '{\"prompt\": \"You are...\", \"voice\": \"alloy\"}'               ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
