# Outbound Caller — ACS + Azure OpenAI Realtime Voice Agent

AI voice calling agent built on Azure Communication Services (ACS) and Azure OpenAI Realtime. Handles both outbound and inbound calls. Fully configurable per-call via HTTP API — change the prompt, voice, VAD sensitivity, and more without redeploying.

The OpenAI WebSocket **only opens when an active call connects** — no idle connections.

---

## Project structure

```
outbound_caller/
├── deploy.sh                     ← one-command Azure deployment
├── Dockerfile
├── .dockerignore
├── .env.example
├── package.json
├── tsconfig.json
└── src/
    ├── app.ts                    ← Express server, ACS client, HTTP endpoints, WebSocket server
    ├── azureOpenAiService.ts     ← OpenAI Realtime connection, session config, reconnect logic
    └── mediaStreamingHandler.ts  ← Parses ACS audio packets and forwards to OpenAI
```

---

## Prerequisites

- [Node.js 20+](https://nodejs.org/en/download)
- [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli)
- [Docker](https://www.docker.com/products/docker-desktop) (for deployment only)
- Azure Communication Services resource with a phone number
- Azure OpenAI or Azure AI Foundry resource with a `gpt-realtime` deployment

---

## Getting your credentials

### Azure Communication Services
1. Azure Portal → your ACS resource → **Keys** → copy **Connection String** → `CONNECTION_STRING`
2. ACS resource → **Phone Numbers** → copy your number → `ACS_PHONE_NUMBER`

### Azure OpenAI / Azure AI Foundry

Your endpoint format depends on how you created the resource:

| Resource type | Endpoint format |
|---|---|
| Azure OpenAI resource | `https://your-resource.openai.azure.com` |
| Azure AI Foundry resource | `https://your-resource.services.ai.azure.com` |

Both work with the `/openai/v1/realtime` path used by this app.

**From Azure AI Foundry ([ai.azure.com](https://ai.azure.com)):**
1. Your project → left sidebar → **Models + endpoints** → click your deployment
2. Copy **Target URI** → `AZURE_OPENAI_SERVICE_ENDPOINT`
3. Copy **Key** → `AZURE_OPENAI_SERVICE_KEY`
4. Copy the deployment name → `AZURE_OPENAI_DEPLOYMENT_MODEL_NAME`

**From Azure OpenAI Service (portal.azure.com):**
1. Your Azure OpenAI resource → **Keys and Endpoint** → copy endpoint and key
2. Azure OpenAI Studio → **Deployments** → copy deployment name

### gpt-realtime (GA) vs gpt-4o-realtime-preview

This app uses the **GA WebSocket format** (`/openai/v1/realtime?model=`). If you deployed `gpt-4o-realtime-preview` instead of `gpt-realtime`, update one line in `src/azureOpenAiService.ts`:

```typescript
// Replace this line:
const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/v1/realtime?model=${deploymentOrModel}`;

// With this (preview format):
const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/realtime?api-version=2025-04-01-preview&deployment=${deploymentOrModel}`;
```

---

## Environment variables

Copy `.env.example` to `.env` and fill in all values:

```env
PORT=8080
CONNECTION_STRING="endpoint=https://YOUR_ACS.communication.azure.com/;accesskey=YOUR_KEY"
CALLBACK_URI="https://YOUR_PUBLIC_URL"
AZURE_OPENAI_SERVICE_KEY="YOUR_KEY"
AZURE_OPENAI_SERVICE_ENDPOINT="https://YOUR_RESOURCE.openai.azure.com"
AZURE_OPENAI_DEPLOYMENT_MODEL_NAME="gpt-realtime"
ACS_PHONE_NUMBER="+1XXXXXXXXXX"
```

---

## Running locally

### 1. Install dependencies

```bash
cd outbound_caller
npm install
```

### 2. Set up a dev tunnel

ACS needs a public HTTPS URL to deliver call events to your local server.

```bash
devtunnel create --allow-anonymous
devtunnel port create -p 8080
devtunnel host
```

Copy the tunnel URL (e.g. `https://abc123-8080.usw3.devtunnels.ms`) into `CALLBACK_URI` in your `.env`.

### 3. Register the ACS Event Grid webhook

Required for inbound calls. Skip if you only need outbound.

1. Azure Portal → your ACS resource → **Events** → **+ Event Subscription**
2. Event type: `IncomingCall`
3. Endpoint URL: `https://YOUR_DEVTUNNEL_URL/api/incomingCall`
4. Save — the server handles the validation handshake automatically

Full instructions: [ACS Incoming Call Notification docs](https://learn.microsoft.com/en-us/azure/communication-services/concepts/call-automation/incoming-call-notification)

### 4. Start the server

```bash
npm run dev
```

### 5. Place a call

**From the terminal prompt:**
```
call +12345678901
```

**Or via HTTP:**
```bash
curl -X POST http://localhost:8080/api/call \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+12345678901"}'
```

---

## Deploying to Azure

### One-command deployment

Edit the config block at the top of `deploy.sh` with your resource names and secrets:

```bash
RESOURCE_GROUP="outbound-caller-rg"
LOCATION="eastus"
ACR_NAME="outboundcallerregistry"    # globally unique, lowercase, no hyphens
APP_NAME="outbound-caller"
ENV_NAME="outbound-caller-env"

CONNECTION_STRING="your-acs-connection-string"
ACS_PHONE_NUMBER="+1XXXXXXXXXX"
AZURE_OPENAI_SERVICE_KEY="your-key"
AZURE_OPENAI_SERVICE_ENDPOINT="https://your-resource.openai.azure.com"
AZURE_OPENAI_DEPLOYMENT_MODEL_NAME="gpt-realtime"
```

Then from inside `outbound_caller/`:

```bash
bash deploy.sh
```

The script handles everything: resource group → container registry → build + push → Container Apps environment → deploy → fetch real URL → update CALLBACK_URI. Prints a summary with your public URL and next steps when done.

### Manual deployment

If you prefer step by step:

```bash
az login
az group create --name outbound-caller-rg --location eastus
az acr create --name outboundcallerregistry --resource-group outbound-caller-rg --sku Basic --admin-enabled true

# From inside outbound_caller/
az acr build --registry outboundcallerregistry --image outbound-caller:latest .

az containerapp env create --name outbound-caller-env --resource-group outbound-caller-rg --location eastus

az containerapp create \
  --name outbound-caller \
  --resource-group outbound-caller-rg \
  --environment outbound-caller-env \
  --image outboundcallerregistry.azurecr.io/outbound-caller:latest \
  --registry-server outboundcallerregistry.azurecr.io \
  --ingress external \
  --target-port 8080 \
  --min-replicas 1 \
  --max-replicas 1 \
  --env-vars \
    PORT=8080 \
    "CONNECTION_STRING=your-acs-connection-string" \
    "ACS_PHONE_NUMBER=+1XXXXXXXXXX" \
    "AZURE_OPENAI_SERVICE_KEY=your-key" \
    "AZURE_OPENAI_SERVICE_ENDPOINT=https://your-resource.openai.azure.com" \
    "AZURE_OPENAI_DEPLOYMENT_MODEL_NAME=gpt-realtime" \
    "CALLBACK_URI=https://placeholder"

# Get the real URL
FQDN=$(az containerapp show --name outbound-caller --resource-group outbound-caller-rg \
  --query properties.configuration.ingress.fqdn -o tsv)

# Update CALLBACK_URI
az containerapp update --name outbound-caller --resource-group outbound-caller-rg \
  --set-env-vars "CALLBACK_URI=https://${FQDN}"
```

### Register the ACS Event Grid webhook (deployed)

1. ACS resource → **Events** → **+ Event Subscription**
2. Endpoint: `https://YOUR_FQDN/api/incomingCall`

### Redeploying after code changes

```bash
# From inside outbound_caller/
az acr build --registry outboundcallerregistry --image outbound-caller:latest .

az containerapp update \
  --name outbound-caller \
  --resource-group outbound-caller-rg \
  --image outboundcallerregistry.azurecr.io/outbound-caller:latest
```

---

## API reference

### `POST /api/call` — Outbound call

Triggers an outbound call. All fields except `phoneNumber` are optional and override defaults for that call only.

```json
{
  "phoneNumber": "+12345678901",
  "prompt": "You are a helpful assistant...",
  "voice": "shimmer",
  "silenceDurationMs": 400,
  "prefixPaddingMs": 300,
  "vadThreshold": 0.5,
  "temperature": 0.8,
  "maxResponseTokens": 4096,
  "greetingMessage": "The person answered. Introduce yourself."
}
```

| Field | Type | Default | Description |
|---|---|---|---|
| `phoneNumber` | string | **required** | E.164 format e.g. `+12345678901` |
| `prompt` | string | built-in default | Full system prompt for the AI |
| `voice` | string | `verse` | `alloy`, `ash`, `ballad`, `coral`, `echo`, `fable`, `onyx`, `nova`, `sage`, `shimmer`, `verse` |
| `silenceDurationMs` | number | `200` | Silence (ms) before AI responds |
| `prefixPaddingMs` | number | `300` | Audio padding before speech detection (ms) |
| `vadThreshold` | number | `0.5` | Voice activity sensitivity 0.0–1.0 |
| `temperature` | number | `0.8` | Response randomness 0.0–1.0 |
| `maxResponseTokens` | number | `4096` | Max tokens per AI turn |
| `greetingMessage` | string | default trigger | Text that kicks off the AI's opening line |

---

### `POST /api/inbound/config` — Configure inbound line

Sets the configuration for **all future inbound calls**. Persists until you change it or restart the server. You only need to call this once per configuration change — not before every call.

```json
{
  "prompt": "You are a support agent for Acme Corp. Greet callers warmly, identify their issue, and help resolve it or route to the right team.",
  "voice": "alloy",
  "silenceDurationMs": 300,
  "greetingMessage": "A customer has just called in. Greet them and ask how you can help."
}
```

Same fields as `/api/call` except no `phoneNumber`. All fields are optional — only the fields you include will be changed.

**Example:**
```bash
curl -X POST https://your-app.azurecontainerapps.io/api/inbound/config \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "You are a support agent for Acme Corp...",
    "voice": "alloy",
    "silenceDurationMs": 300
  }'
```

---

### `GET /api/inbound/config` — View current inbound config

Returns the currently active inbound configuration.

```bash
curl https://your-app.azurecontainerapps.io/api/inbound/config
```

---

### `DELETE /api/inbound/config` — Reset inbound config

Resets inbound config back to defaults.

```bash
curl -X DELETE https://your-app.azurecontainerapps.io/api/inbound/config
```

---

## Default prompts

If no prompt is passed, the AI uses a built-in generic default. These live in `src/azureOpenAiService.ts` as `DEFAULT_OUTBOUND_PROMPT` and `DEFAULT_INBOUND_PROMPT`. Edit them to change the baseline behavior without passing a prompt on every call.

---

## How it works

1. You call `POST /api/call` (or type `call +1...` locally) — config is stored keyed by a UUID
2. ACS places the call. When the recipient answers, ACS opens a WebSocket to your server passing `?callId=UUID`
3. The server looks up the config for that callId and opens the OpenAI Realtime WebSocket with those parameters
4. For inbound: when a call arrives at `/api/incomingCall`, the current `inboundConfig` is captured and stored the same way
5. Audio flows: Caller → ACS → your server → OpenAI → your server → ACS → Caller
6. When the call ends, the ACS socket closes, OpenAI socket closes, reconnect stops

The OpenAI connection is never opened unless there is an active call.

### Reconnection behavior

If the OpenAI WebSocket drops mid-call:
- Retries up to 5 times with increasing backoff: 2s, 4s, 6s, 8s, 10s
- Stops retrying if the ACS call has already ended
- Pings OpenAI every 30 seconds to prevent idle timeout disconnects

---

## Supported regions for gpt-realtime

`gpt-realtime` supports global deployments but underlying compute runs in **East US 2** and **Sweden Central**. Deploy your Container App in `eastus2` if latency matters.

---

## Troubleshooting

| Problem | What to check |
|---|---|
| Call connects but AI doesn't speak | Verify `CALLBACK_URI` is publicly reachable and correct. ACS must POST to `/api/callbacks/:id`. |
| OpenAI WebSocket 401 | Key is wrong or expired. |
| OpenAI WebSocket 404 | Deployment name doesn't match exactly (case-sensitive). Also check GA vs preview endpoint format. |
| Using `gpt-4o-realtime-preview` and getting 404 | Switch to preview endpoint format in `azureOpenAiService.ts` — see credentials section above. |
| EventGrid webhook not firing for inbound | Confirm webhook is registered in ACS → Events pointing to the correct `/api/incomingCall` URL. |
| Inbound config not applying | Check `GET /api/inbound/config` — the server must be running and the config must have been set after the last restart. |
| Container App crashes on start | Check logs: `az containerapp logs show --name outbound-caller --resource-group outbound-caller-rg --follow` |
| `CALLBACK_URI` wrong after deploy | Run: `az containerapp update --name outbound-caller --resource-group outbound-caller-rg --set-env-vars "CALLBACK_URI=https://YOUR_REAL_FQDN"` |
