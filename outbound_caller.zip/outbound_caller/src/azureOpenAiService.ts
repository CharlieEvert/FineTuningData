import WebSocket from 'ws';
import { config } from 'dotenv';
import { createOutboundAudioData, createOutboundStopAudioData } from '@azure/communication-call-automation';

config();

let ws: WebSocket;
let realtimeWs: WebSocket;
let reconnectAttempts = 0;
let isCallActive = false;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY_MS = 2000;

const openAiServiceEndpoint = process.env.AZURE_OPENAI_SERVICE_ENDPOINT || "";
const openAiKey = process.env.AZURE_OPENAI_SERVICE_KEY || "";
const openAiDeploymentModel = process.env.AZURE_OPENAI_DEPLOYMENT_MODEL_NAME || "";

// ─── Default prompts ──────────────────────────────────────────────────────────

export const DEFAULT_OUTBOUND_PROMPT = `You are a helpful AI voice assistant making an outbound call. Be concise, friendly, and professional. Listen carefully and respond naturally. Keep responses brief and conversational.`;

export const DEFAULT_INBOUND_PROMPT = `You are a helpful AI voice assistant answering an inbound call. Greet the caller warmly, listen to their needs, and assist them as best you can. Be concise and professional.`;

const DEFAULT_OUTBOUND_GREETING = "The person has answered the phone. Introduce yourself briefly and ask how you can help.";
const DEFAULT_INBOUND_GREETING = "A caller has just connected. Greet them warmly and ask how you can help.";

// ─── Per-call config type ─────────────────────────────────────────────────────

export interface CallConfig {
  /** Override the system prompt entirely */
  prompt?: string;
  /**
   * Voice name. Options: alloy, ash, ballad, coral, echo, fable, onyx, nova,
   * sage, shimmer, verse
   */
  voice?: string;
  /** VAD silence duration in ms before triggering response (default 200) */
  silenceDurationMs?: number;
  /** VAD prefix padding in ms (default 300) */
  prefixPaddingMs?: number;
  /** VAD activation threshold 0.0–1.0 (default 0.5) */
  vadThreshold?: number;
  /** Sampling temperature 0.0–1.0 (default 0.8) */
  temperature?: number;
  /** Max tokens per response (default 4096) */
  maxResponseTokens?: number;
  /** Override the trigger text that starts the AI's opening line */
  greetingMessage?: string;
}

// ─── Defaults ─────────────────────────────────────────────────────────────────

const DEFAULTS: Required<Omit<CallConfig, 'prompt' | 'greetingMessage'>> = {
  voice: "verse",
  silenceDurationMs: 200,
  prefixPaddingMs: 300,
  vadThreshold: 0.5,
  temperature: 0.8,
  maxResponseTokens: 4096,
};

// ─── WebSocket state ──────────────────────────────────────────────────────────

export async function initWebsocket(socket: WebSocket) {
  ws = socket;
  isCallActive = true;
  reconnectAttempts = 0;
  console.log("✅ ACS WebSocket initialized");

  ws.on('close', () => {
    console.log("📡 ACS WebSocket closed — marking call inactive");
    isCallActive = false;
    if (realtimeWs && realtimeWs.readyState === WebSocket.OPEN) {
      realtimeWs.close();
    }
  });
}

export async function sendAudioToExternalAi(data: string) {
  try {
    if (realtimeWs && realtimeWs.readyState === WebSocket.OPEN) {
      realtimeWs.send(JSON.stringify({ type: "input_audio_buffer.append", audio: data }));
    }
  } catch (e) {
    console.error("Error sending audio to OpenAI:", e);
  }
}

export async function startConversation(
  callConfig?: CallConfig,
  defaultPrompt?: string,
  defaultGreeting?: string
) {
  await startRealtime(
    openAiServiceEndpoint,
    openAiKey,
    openAiDeploymentModel,
    callConfig,
    defaultPrompt,
    defaultGreeting
  );
}

// ─── Realtime connection ──────────────────────────────────────────────────────

async function startRealtime(
  endpoint: string,
  apiKey: string,
  deploymentOrModel: string,
  callConfig?: CallConfig,
  defaultPrompt?: string,
  defaultGreeting?: string
) {
  try {
    console.log("\n=== STARTING REALTIME CONNECTION ===");
    console.log(`Endpoint: ${endpoint}`);
    console.log(`Model: ${deploymentOrModel}`);
    console.log(`API Key present: ${apiKey ? 'YES' : 'NO'}`);

    const cfg = { ...DEFAULTS, ...callConfig };
    const prompt = callConfig?.prompt ?? defaultPrompt ?? DEFAULT_OUTBOUND_PROMPT;
    const greetingMessage = callConfig?.greetingMessage ?? defaultGreeting ?? DEFAULT_OUTBOUND_GREETING;

    const baseUrl = endpoint.replace(/\/$/, "");
    const wsUrl = `${baseUrl.replace('https://', 'wss://')}/openai/v1/realtime?model=${deploymentOrModel}`;
    console.log(`WebSocket URL: ${wsUrl}`);

    realtimeWs = new WebSocket(wsUrl, { headers: { 'api-key': apiKey } });

    const pingInterval = setInterval(() => {
      if (realtimeWs.readyState === WebSocket.OPEN) {
        realtimeWs.ping();
      } else {
        clearInterval(pingInterval);
      }
    }, 30000);

    realtimeWs.on('pong', () => console.log("🏓 Pong from OpenAI"));

    realtimeWs.on('open', () => {
      reconnectAttempts = 0;
      console.log("✅ OpenAI WebSocket OPENED");
    });

    realtimeWs.on('message', async (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        console.log(`📨 Event: ${message.type}`);

        if (message.type === "session.created") {
          console.log(`🎯 SESSION CREATED (${message.session?.id}) — sending config`);

          const sessionConfig = {
            type: "session.update",
            session: {
              type: "realtime",
              instructions: prompt,
              output_modalities: ["audio"],
              temperature: cfg.temperature,
              max_response_output_tokens: cfg.maxResponseTokens,
              audio: {
                input: {
                  transcription: { model: "whisper-1" },
                  format: { type: "audio/pcm", rate: 24000 },
                  turn_detection: {
                    type: "server_vad",
                    threshold: cfg.vadThreshold,
                    prefix_padding_ms: cfg.prefixPaddingMs,
                    silence_duration_ms: cfg.silenceDurationMs,
                    create_response: true
                  }
                },
                output: {
                  voice: cfg.voice,
                  format: { type: "audio/pcm", rate: 24000 }
                }
              }
            }
          };

          console.log(`Prompt length: ${prompt.length} chars | Voice: ${cfg.voice} | VAD silence: ${cfg.silenceDurationMs}ms`);
          realtimeWs.send(JSON.stringify(sessionConfig));
          console.log("✅ Session update sent");
        }

        if (message.type === "session.updated") {
          console.log("✅ SESSION UPDATED — triggering greeting");
          triggerInitialGreeting(greetingMessage);
        }

        await handleRealtimeMessages(message);
      } catch (error) {
        console.error('❌ Error parsing message:', error);
      }
    });

    realtimeWs.on('error', (err) => {
      console.error("❌ OpenAI WebSocket ERROR:", err);
      clearInterval(pingInterval);
    });

    realtimeWs.on('close', (code) => {
      console.log(`🔌 OpenAI WebSocket CLOSED — code: ${code}`);
      clearInterval(pingInterval);
      attemptReconnect(endpoint, apiKey, deploymentOrModel, callConfig, defaultPrompt, defaultGreeting);
    });

  } catch (error) {
    console.error("❌ Error during startRealtime:", error);
    attemptReconnect(endpoint, apiKey, deploymentOrModel, callConfig, defaultPrompt, defaultGreeting);
  }
}

function attemptReconnect(
  endpoint: string,
  apiKey: string,
  deploymentOrModel: string,
  callConfig?: CallConfig,
  defaultPrompt?: string,
  defaultGreeting?: string
) {
  if (!isCallActive) {
    console.log("📞 Call inactive — skipping reconnect");
    return;
  }
  if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
    console.error(`❌ Max reconnect attempts (${MAX_RECONNECT_ATTEMPTS}) reached`);
    return;
  }
  reconnectAttempts++;
  const delay = RECONNECT_DELAY_MS * reconnectAttempts;
  console.log(`🔄 Reconnect ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} in ${delay}ms...`);
  setTimeout(() => startRealtime(endpoint, apiKey, deploymentOrModel, callConfig, defaultPrompt, defaultGreeting), delay);
}

function triggerInitialGreeting(greetingMessage: string) {
  realtimeWs.send(JSON.stringify({
    type: "conversation.item.create",
    item: {
      type: "message",
      role: "user",
      content: [{ type: "input_text", text: greetingMessage }]
    }
  }));
  realtimeWs.send(JSON.stringify({ type: "response.create" }));
  console.log("✅ Initial greeting triggered");
}

async function handleRealtimeMessages(message: any) {
  switch (message.type) {
    case "session.created":
    case "session.updated":
      break;
    case "response.output_audio_transcript.delta":
      process.stdout.write(message.delta);
      break;
    case "response.output_audio_transcript.done":
      console.log(`\n🤖 AI: ${message.transcript}\n`);
      break;
    case "response.output_audio.delta":
      await receiveAudioForOutbound(message.delta);
      break;
    case "input_audio_buffer.speech_started":
      console.log("🎙️  User speaking — stopping playback");
      stopAudio();
      break;
    case "input_audio_buffer.speech_stopped":
      console.log("🎙️  User stopped speaking");
      break;
    case "conversation.item.created":
      console.log(`💬 Item: ${message.item?.type}`);
      break;
    case "response.created":
      console.log(`🎯 Response: ${message.response?.id}`);
      break;
    case "response.done":
      console.log(`✅ Done: ${message.response?.id}`);
      break;
    case "error":
      console.error(`❌ OpenAI ERROR: [${message.error?.code}] ${message.error?.message}`);
      break;
    default:
      console.log(`📝 ${message.type}`);
  }
}

async function receiveAudioForOutbound(data: string) {
  try {
    sendMessageToAcs(createOutboundAudioData(data));
  } catch (e) {
    console.error("Error creating outbound audio:", e);
  }
}

async function stopAudio() {
  try {
    sendMessageToAcs(createOutboundStopAudioData());
    console.log("🛑 Stopped audio playback");
  } catch (e) {
    console.error("Error stopping audio:", e);
  }
}

function sendMessageToAcs(data: string) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(data);
  } else {
    console.warn("⚠️  Cannot send to ACS — WebSocket not open");
  }
}
