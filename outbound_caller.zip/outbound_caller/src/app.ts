import { config } from 'dotenv';
import express, { Application } from 'express';
import http from 'http';
import * as readline from 'readline';
import {
	CallAutomationClient,
	AnswerCallOptions,
	AnswerCallResult,
	MediaStreamingOptions,
	CreateCallOptions,
	CallInvite,
} from "@azure/communication-call-automation";
import { PhoneNumberIdentifier } from "@azure/communication-common";
import { v4 as uuidv4 } from 'uuid';
import WebSocket from 'ws';
import {
	startConversation,
	initWebsocket,
	CallConfig,
	DEFAULT_OUTBOUND_PROMPT,
	DEFAULT_INBOUND_PROMPT,
} from './azureOpenAiService';
import { processWebsocketMessageAsync } from './mediaStreamingHandler';

config();

const PORT = process.env.PORT;
const app: Application = express();
app.use(express.json());
const server = http.createServer(app);

let acsClient: CallAutomationClient;

// ─── Inbound config (persists across calls until changed) ─────────────────────
let inboundConfig: CallConfig = {};

// ─── Per-call config store (keyed by callId UUID) ────────────────────────────
const pendingCallConfigs = new Map<string, { config: CallConfig; type: 'outbound' | 'inbound' }>();

// ─── ACS client ───────────────────────────────────────────────────────────────

async function createAcsClient() {
	const connectionString = process.env.CONNECTION_STRING || "";
	acsClient = new CallAutomationClient(connectionString);
	console.log("Initialized ACS Client.");
}

// ─── Outbound call ────────────────────────────────────────────────────────────

async function makeOutboundCall(targetPhoneNumber: string, callConfig?: CallConfig) {
	try {
		const sourcePhoneNumber = process.env.ACS_PHONE_NUMBER || "";
		if (!sourcePhoneNumber) {
			console.error("ACS_PHONE_NUMBER not configured");
			return;
		}

		const callId = uuidv4();
		const callbackUri = `${process.env.CALLBACK_URI}/api/callbacks/${callId}?callerId=${targetPhoneNumber}`;
		const websocketUrl = process.env.CALLBACK_URI.replace(/^https:\/\//, 'wss://');

		pendingCallConfigs.set(callId, { config: callConfig || {}, type: 'outbound' });

		const mediaStreamingOptions: MediaStreamingOptions = {
			transportUrl: `${websocketUrl}?callId=${callId}`,
			transportType: "websocket",
			contentType: "audio",
			audioChannelType: "unmixed",
			startMediaStreaming: true,
			enableBidirectional: true,
			audioFormat: "Pcm24KMono"
		};

		const target: CallInvite = {
			targetParticipant: { phoneNumber: targetPhoneNumber } as PhoneNumberIdentifier,
			sourceCallIdNumber: { phoneNumber: sourcePhoneNumber } as PhoneNumberIdentifier,
		};

		console.log(`Placing outbound call to ${targetPhoneNumber}...`);
		const callResult = await acsClient.createCall(
			target,
			callbackUri,
			{ mediaStreamingOptions }
		);
		console.log(`✅ Outbound call created - Connection ID: ${callResult.callConnectionProperties.callConnectionId}`);
	} catch (error) {
		console.error("❌ Error making outbound call:", error);
	}
}

// ─── Terminal input (local dev only) ─────────────────────────────────────────

function setupTerminalInput() {
	const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
	console.log('\n📞 Terminal ready. Commands:');
	console.log('  call <+phone>   — place an outbound call');
	console.log('  exit            — quit\n');

	rl.on('line', async (input: string) => {
		const trimmed = input.trim();
		if (trimmed.toLowerCase() === 'exit') { process.exit(0); }
		const callMatch = trimmed.match(/^call\s+(\+?\d+)$/i);
		if (callMatch) {
			const phoneNumber = callMatch[1];
			if (!phoneNumber.startsWith('+')) {
				console.log('⚠️  Include country code e.g. +12345678901');
				return;
			}
			await makeOutboundCall(phoneNumber);
		} else {
			console.log('❓ Unknown command. Use: call <phone-number>');
		}
	});
}

// ─── HTTP Endpoints ───────────────────────────────────────────────────────────

/**
 * POST /api/call
 * Trigger an outbound call with optional per-call config overrides.
 *
 * Body:
 *   phoneNumber        string   required
 *   prompt             string   optional — full system prompt override
 *   voice              string   optional — alloy|ash|ballad|coral|echo|fable|onyx|nova|sage|shimmer|verse
 *   silenceDurationMs  number   optional — VAD silence ms (default 200)
 *   prefixPaddingMs    number   optional — VAD prefix padding ms (default 300)
 *   vadThreshold       number   optional — VAD threshold 0.0–1.0 (default 0.5)
 *   temperature        number   optional — 0.0–1.0 (default 0.8)
 *   maxResponseTokens  number   optional — (default 4096)
 *   greetingMessage    string   optional — text that triggers the AI's opening line
 */
app.post("/api/call", async (req: any, res: any) => {
	const {
		phoneNumber,
		prompt,
		voice,
		silenceDurationMs,
		prefixPaddingMs,
		vadThreshold,
		temperature,
		maxResponseTokens,
		greetingMessage,
	} = req.body;

	if (!phoneNumber) return res.status(400).json({ error: "phoneNumber required" });

	const callConfig: CallConfig = {
		...(prompt !== undefined && { prompt }),
		...(voice !== undefined && { voice }),
		...(silenceDurationMs !== undefined && { silenceDurationMs }),
		...(prefixPaddingMs !== undefined && { prefixPaddingMs }),
		...(vadThreshold !== undefined && { vadThreshold }),
		...(temperature !== undefined && { temperature }),
		...(maxResponseTokens !== undefined && { maxResponseTokens }),
		...(greetingMessage !== undefined && { greetingMessage }),
	};

	await makeOutboundCall(phoneNumber, callConfig);
	res.status(200).json({ message: `Calling ${phoneNumber}`, config: callConfig });
});

/**
 * POST /api/inbound/config
 * Set the configuration for all future inbound calls.
 * Config persists until changed again — you don't need to set it before every call.
 *
 * Body: same optional fields as /api/call (minus phoneNumber)
 *
 * Example:
 *   curl -X POST https://your-app.azurecontainerapps.io/api/inbound/config \
 *     -H "Content-Type: application/json" \
 *     -d '{
 *           "prompt": "You are a support agent for Acme Corp...",
 *           "voice": "alloy",
 *           "silenceDurationMs": 300
 *         }'
 */
app.post("/api/inbound/config", (req: any, res: any) => {
	const {
		prompt,
		voice,
		silenceDurationMs,
		prefixPaddingMs,
		vadThreshold,
		temperature,
		maxResponseTokens,
		greetingMessage,
	} = req.body;

	inboundConfig = {
		...(prompt !== undefined && { prompt }),
		...(voice !== undefined && { voice }),
		...(silenceDurationMs !== undefined && { silenceDurationMs }),
		...(prefixPaddingMs !== undefined && { prefixPaddingMs }),
		...(vadThreshold !== undefined && { vadThreshold }),
		...(temperature !== undefined && { temperature }),
		...(maxResponseTokens !== undefined && { maxResponseTokens }),
		...(greetingMessage !== undefined && { greetingMessage }),
	};

	console.log(`📋 Inbound config updated:`, JSON.stringify(inboundConfig, null, 2));
	res.status(200).json({ message: "Inbound config updated", config: inboundConfig });
});

/**
 * GET /api/inbound/config
 * Returns the current inbound call configuration.
 */
app.get("/api/inbound/config", (req: any, res: any) => {
	res.status(200).json({ config: inboundConfig });
});

/**
 * DELETE /api/inbound/config
 * Resets inbound config back to defaults.
 */
app.delete("/api/inbound/config", (req: any, res: any) => {
	inboundConfig = {};
	console.log("📋 Inbound config reset to defaults");
	res.status(200).json({ message: "Inbound config reset to defaults" });
});

app.post("/api/incomingCall", async (req: any, res: any) => {
	const event = req.body[0];
	try {
		const eventData = event.data;
		if (event.eventType === "Microsoft.EventGrid.SubscriptionValidationEvent") {
			console.log("Received SubscriptionValidation event");
			res.status(200).json({ validationResponse: eventData.validationCode });
			return;
		}

		const callerId = eventData.from.rawId;
		const callId = uuidv4();
		const callbackUri = `${process.env.CALLBACK_URI}/api/callbacks/${callId}?callerId=${callerId}`;
		const incomingCallContext = eventData.incomingCallContext;
		const websocketUrl = process.env.CALLBACK_URI.replace(/^https:\/\//, 'wss://');

		// Tag this as an inbound call so WS handler picks up inbound config
		pendingCallConfigs.set(callId, { config: { ...inboundConfig }, type: 'inbound' });

		const mediaStreamingOptions: MediaStreamingOptions = {
			transportUrl: `${websocketUrl}?callId=${callId}`,
			transportType: "websocket",
			contentType: "audio",
			audioChannelType: "unmixed",
			startMediaStreaming: true,
			enableBidirectional: true,
			audioFormat: "Pcm24KMono"
		};

		const answerCallOptions: AnswerCallOptions = { mediaStreamingOptions };
		const result = await acsClient.answerCall(incomingCallContext, callbackUri, answerCallOptions);
		console.log(`✅ Answered inbound call - Connection ID: ${result.callConnectionProperties.callConnectionId}`);
		res.status(200).send();
	} catch (error) {
		console.error("❌ Error answering incoming call:", error);
		res.status(500).send();
	}
});

app.post('/api/callbacks/:contextId', async (req: any, res: any) => {
	const event = req.body[0];
	const eventData = event.data;
	const callConnectionId = eventData.callConnectionId;
	console.log(`Received Event: ${event.type}, CallConnectionId: ${callConnectionId}`);

	if (event.type === "Microsoft.Communication.CallConnected") {
		const props = await acsClient.getCallConnection(callConnectionId).getCallConnectionProperties();
		console.log("MediaStreamingSubscription: " + JSON.stringify(props.mediaStreamingSubscription));
	} else if (event.type === "Microsoft.Communication.MediaStreamingStarted") {
		console.log(`Media streaming status: ${eventData.mediaStreamingUpdate.mediaStreamingStatus}`);
	} else if (event.type === "Microsoft.Communication.MediaStreamingStopped") {
		console.log(`Media streaming stopped`);
	} else if (event.type === "Microsoft.Communication.MediaStreamingFailed") {
		console.log(`Streaming failed - Code: ${eventData.resultInformation.code}, Message: ${eventData.resultInformation.message}`);
	} else if (event.type === "Microsoft.Communication.CallDisconnected") {
		console.log("📞 Call disconnected");
	}

	res.status(200).send();
});

app.get('/', (req, res) => res.send('ACS + OpenAI Realtime Voice Agent running.'));

// ─── Server + WebSocket ───────────────────────────────────────────────────────

server.listen(PORT, async () => {
	console.log(`🚀 Server listening on port ${PORT}`);
	await createAcsClient();
	setupTerminalInput();
});

const wss = new WebSocket.Server({ server });

wss.on('connection', async (ws: WebSocket, req) => {
	console.log('📡 Client connected to WebSocket');

	const urlParams = new URLSearchParams(req.url?.split('?')[1] || '');
	const callId = urlParams.get('callId');
	const entry = callId ? pendingCallConfigs.get(callId) : undefined;

	if (callId && entry) {
		pendingCallConfigs.delete(callId);
		console.log(`📋 Using ${entry.type} config for callId: ${callId}`);
	}

	const callConfig = entry?.config;
	const isInbound = entry?.type === 'inbound';

	const defaultPrompt = isInbound ? DEFAULT_INBOUND_PROMPT : DEFAULT_OUTBOUND_PROMPT;
	const defaultGreeting = isInbound
		? "A caller has just connected. Greet them warmly and ask how you can help."
		: "The person has answered the phone. Introduce yourself briefly and ask how you can help.";

	await initWebsocket(ws);
	await startConversation(callConfig, defaultPrompt, defaultGreeting);

	ws.on('message', async (packetData: ArrayBuffer) => {
		try {
			if (ws.readyState === WebSocket.OPEN) {
				await processWebsocketMessageAsync(packetData);
			} else {
				console.warn(`⚠️  ReadyState: ${ws.readyState}`);
			}
		} catch (error) {
			console.error('❌ Error processing WebSocket message:', error);
		}
	});

	ws.on('close', () => console.log('📡 Client disconnected from WebSocket'));
});

console.log(`🔌 WebSocket server running on port ${PORT}`);
